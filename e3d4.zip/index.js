const express = require("express")
const app = express()
const cookieParser = require('cookie-parser')
const connectionWithDb = require('./db')
const session = require('express-session')
const passport = require("passport")
require('./controller/auth/google')
require('./controller/auth/facebook')
const cookieAuth = require('./middleware/authCookie')

app.set('view engine', 'ejs');
app.use('/sites/e4d4/assets',express.static(__dirname + '/views/assets'));


const PORT = process.env.PORT || 8080;

connectionWithDb()
app.use(cookieParser())
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(session({
    secret: 'E4D4-Secret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}))
app.use(passport.initialize())
app.use(cookieAuth('authtoken'));


app.get('/sites/e4d4/', async (req, res) => {
    const user = req.user
    const business = req.business
    console.log('user', user)
    res.render(`index`, { user, business })
})

app.get('/sites/e4d4/businessdetails', async (req, res) => {
    const user = req.user
    const business = req.business
    res.render(`businessdetails`, { user, business })
})

app.get('/sites/e4d4/businessregistration', async (req, res) => {
    const user = req.user
    const business = req.business
    res.render(`businessregistration`, { user, business })
})

app.get('/sites/e4d4/dashboard-main', async (req, res) => {
    const user = req.user
    const business = req.business
    if (!user) {
        return res.redirect(`/sites/e4d4/join`)
    }
    res.render(`dashboard-2`, { user, business })
})

app.get('/sites/e4d4/dashboard', async (req, res) => {
    const user = req.user
    const business = req.business
    if (user) {
        return res.render(`dashboard`, { user, business })
    }
    return res.redirect(`/sites/e4d4/join`)
})

app.get('/sites/e4d4/join', async (req, res) => {
    const user = req.user
    const business = req.business
    if(user){
        return res.redirect(`/sites/e4d4/dashboard`)
    }
    return res.render(`join`, { user, business })
})
app.get('/sites/e4d4/user-loginemail', async (req, res) => {
    const user = req.user
    const business = req.business
    res.render(`user-loginemail`, { user, business })
})
app.get('/sites/e4d4/user-login', async (req, res) => {
    const user = req.user
    const business = req.business
    res.render(`user-login`, { user, business })
})
app.get('/sites/e4d4/business-login', async (req, res) => {
    const user = req.user
    const business = req.business
    res.render(`business-login`, { user, business })
})

app.get('/sites/e4d4/portfolioreg', async (req, res) => {
    const user = req.user || req.session?.passport?.user
    const business = req.business
    res.render(`portfolioreg`, { user, business })
})

app.get('/sites/e4d4/profilepicture', async (req, res) => {
    const user = req.user
    const business = req.business
    if (!user) {
        return res.redirect(`/sites/e4d4/join`)
    }
    res.render(`profilepicture`, { user, business })
})
app.get('/sites/e4d4/business-subscription', async (req, res) => {
    const user = req.user
    const business = req.business
    if (!business) {
        return res.redirect(`/sites/e4d4/business-login`)
    }
    res.render(`business-subscription`, { user, business })
})

app.get('/sites/e4d4/searchprofilehistory', async (req, res) => {
    const user = req.user
    const business = req.business
    if (!user) {
        return res.redirect(`/sites/e4d4/join`)
    }
    res.render(`searchprofilehistory`, { user, business })
})

app.get('/sites/e4d4/userregistration', async (req, res) => {
    const user = req.user
    const business = req.business
    res.render(`userregistration`, { user, business })
})

app.get('/sites/e4d4/jobposting', async (req, res) => {
    const user = req.user
    const business = req.business
    res.render(`jobposting`, { user, business })
})
app.get('/sites/e4d4/jobdetails', async (req, res) => {
    const user = req.user
    const business = req.business
    res.render(`jobdetails`, { user, business })
})

app.use('/sites/e4d4/api', require('./controller/apihandler'))

app.listen(PORT, () => {
    console.log(`App is listening on PORT: http://localhost:${PORT}/sites/e4d4`)
})